package com.example.myandroidapp2

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val message = TextView(this).apply {
            text = "Hello from MyAndroidApp2"
            textSize = 22f
            gravity = Gravity.CENTER
        }
        setContentView(message)
    }
}
