package com.example.myirstapp

import android.content.Intent
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var url by remember { mutableStateOf("https://www.google.com") }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "Welcome to MyFirstApp",
                    style = MaterialTheme.typography.headlineMedium,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    label = { Text("Website URL") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                )

                Button(
                    onClic = {
                        var websiteUrl = url.trim()
                        if (!websiteUrl.startsWith("http://") && !websiteUrl.startsWith("https://")) {
                            websiteUrl = "https://" + websiteUrl
                        }
                        val intent = Intent(this@MainActivity, WebViewActivity::class.java)
                        intent.putExtra("url", websiteUrl)
                        startActivity(intent)
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Open Website")
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedButton(
                    onClic = {
                        if (checkSelfPermission(android.Manifest.permission.CAMERA) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                            requestPermissions(arrayOf(android.Manifest.permission.CAMERA), 100)
                        } else {
                            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                            try {
                                startActivity(intent)
                            } catch (e: Exception) {
                                android.widget.Toast.makeText(this@MainActivity, "Camera not available: " + e.message, android.widget.Toast.LENGTH_SHORT).show()
                            }
                        } 
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Open Camera")
                }
            }
        }
    }
}