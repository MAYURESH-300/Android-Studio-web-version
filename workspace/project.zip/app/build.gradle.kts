plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {

androidResources {
    noCompress += listOf("glb", "gltf", "obj", "fbx", "dae", "3ds", "blend", "bin", "dat", "mp4", "mp3", "wav", "mkv", "mov", "avi", "3gp", "ogg", "flac", "tga", "pdf", "zip", "7z", "rar")
}
    namespace = "com.mimics.myapplication"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.mimics.myapplication"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
}

dependencies {
    implementation("io.coil-kt:coil-compose:2.6.0")
    implementation(libs.androidx.activity.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.androidx.core.ktx)
    implementation(libs.material)
}